package com.example.raccontodolist

//Classe Lista contém os valores utilizados dentro da lista
//titulo é uma String com o texto da tarefa adicionada Ex: Dar banho no cachorro.
//assinalado é um Boolean que indica se a caixa está marcada ou não.
data class Lista (
    val titulo: String,
    var assinalado: Boolean = false
    )