package com.example.raccontodolist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    //Declara FuncionamentoLista
    private lateinit var listaAdapter: FuncionamentoLista

    //Chama quando iniciar o aplicativo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listaAdapter = FuncionamentoLista(mutableListOf())  //Inicia Variável, lista começa vazia

        //Chamada de listaAdapter para o RecyclerView
        rvLista.adapter = listaAdapter

        //Chamada de layoutManager para RecyclerView
        rvLista.layoutManager = LinearLayoutManager(this) //LinearLayoutManager faz arranjo como uma lista

        //Comportamento do botão de Adicionar Tarefa
        //Ao clicar, atribui o valor de Edit Text a textoBotão
        //Se não estiver vazio, adiciona um item na lista e esvazia a caixa de texto
        btnAdicionarTarefa.setOnClickListener {
            val textoBotao = etTituloLista.text.toString()
            if(textoBotao.isNotEmpty()){
                val lista = Lista(textoBotao)
                listaAdapter.addItem(lista)
                etTituloLista.text.clear()
            }
        }

        //Comportamento do botão de Apagar Tarefa
        //Se clicado, chama a função apagarItens de FuncionamentoLista
        btnApagarTarefa.setOnClickListener {
            listaAdapter.apagarItens()
        }
    }
}