package com.example.raccontodolist

import android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_lista.view.*

/*
A Classe FuncionamentoLista é responsável pela lógica de inserção e remoção da lista.
Ela também define o comportamento do botão de Checkbox.
Além disso ela também define o comportamento do texto quando a checkbox está ou não marcada (hachura)
 */

class FuncionamentoLista ( private val lista: MutableList<Lista> )
    : RecyclerView.Adapter <FuncionamentoLista.ListaViewHolder>()
{
    //RecyclerView permite melhor funcionamento do app.
    //Diferente da lista padrão ela carrega apenas os itens que são visiveis ao usuário, aumentando a performance.
    class ListaViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView)

    //Usa o arquivo xml item_lista e cria a View
    //Parâmetros: Herda ListaViewHolder
    //retorna ListaViewHolder e cria a View
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListaViewHolder {
        return ListaViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_lista, parent, false)
        )
    }

    //Adiciona item na lista
    //Parâmetro: item (do tipo Lista, contém a String com o texto e o Boolean se esta marcado)
    //Não há retorno
    fun addItem (item: Lista){
        lista.add(item)
        notifyItemInserted(lista.size - 1)
    }

    //Apaga todos os itens marcados
    //Não há parâmetros, percorre toda a lista e checa quais estão com assinalado = true
    //Não há retorno, apenas apaga todos os itens marcados.
    fun apagarItens(){
        lista.removeAll { lista ->
            lista.assinalado
        }
        notifyDataSetChanged()
    }

    //Hachura texto de item marcado
    //Parâmetros: tvTituloLista-> texto do item na lista, assinalado->indica se a checkbox = true
    //Não há retorno, hachura texto e remove a hachura caso boolean seja true xor false
    private fun toggleStrikeThrough(tvTituloLista: TextView, assinalado: Boolean){
        if(assinalado){
            tvTituloLista.paintFlags = tvTituloLista.paintFlags or STRIKE_THRU_TEXT_FLAG
        }
        else{
            tvTituloLista.paintFlags = tvTituloLista.paintFlags and STRIKE_THRU_TEXT_FLAG.inv()
        }
    }

    //Coloca informação do texto e da checkbox na lista atual
    //Parâmetros: Classe ListaViewHolder que carrega a lista, inteiro com a posição
    //Não há retorno
    override fun onBindViewHolder(holder: ListaViewHolder, position: Int) {
        val listaAtual = lista[position]
        holder.itemView.apply {
            tvTituloLista.text = listaAtual.titulo  //Carrega no xml o texto do item
            cbTarefaTerminada.isChecked = listaAtual.assinalado     //Carrega no xml se o item está assinalado ou não
            toggleStrikeThrough(tvTituloLista, listaAtual.assinalado)   //Chama a função de hachurar item
            cbTarefaTerminada.setOnCheckedChangeListener{ _, isChecked ->   //Caso haja mudança na checklist, atualiza essas mudanças.
                toggleStrikeThrough(tvTituloLista, isChecked)
                listaAtual.assinalado = !listaAtual.assinalado
            }
        }
    }

    //Pega número de itens na lista.
    //Não há parâmetros
    //Retorna inteiro com o tamanho da lista
    override fun getItemCount(): Int {
        return lista.size
    }
}