=RacconToDoList=

Aplicativo Android criado para o processo seletivo da Raccon Marketing Digital. 
Aplicativo de armazenamento de tarefas com as seguintes funcionalidades:

Visulizar tarefas salvas.
Completar uma tarefa.
Salvar nova tarefa.
Deletar tarefa salva.

Não há banco de dados, portanto, ao fechar o aplicativo, os dados serão perdidos.

Linguagens: Kotlin (programação) e XML (marcação)
Data: 19/7/2021
Criado por: Rafael Olivier Cardoso

O aplicativo foi desenvolvido no programa Android Studio. As instruções para compilar e rodar serão através desse programa.

1. Se não tiver Android Studio instalado, baixe-o e instale. A versão mais recente pode ser encontrada em https://developer.android.com/studio. 
Durante a instalação, instale também o Android Virtual Device.
	1.1. O Android Virtual Device permite criar uma máquina virtual simulando sistema Android. É possível também abrir em um celular físico.
2. Abra o Android Studio. Clique em abrir projeto existente e abra o projeto RacconToDoList. Estará no diretório onde você descompactou os arquivos.
3. Após abrir o projeto, no canto superior direito da UI do Android Studio, estará um botão AVD Manager. Clique para abrir.
	3.1. Se já tiver uma máquina virtual selecionada (Caso já tenha usado Android Studio anteriormente, por exemplo, pode pular ao passo 9)
4. Se não houver nenhum virtual device instalado, clique em + Create Virtual Device. 
5. Na nova tela, na aba Phone, selecione o telefone de sua preferência. Para o teste do desenvolvedor, foi usado Pixel 2. Clique em next.
6. Em System Image, na aba Recommended, selecione R. Esse aplicativo foi desenvolvido na versão 30.0.2. Clique em next.
	6.1. A versão 31.0.0, no presente momento, apresentou alguns problemas.
7. Clique em Finish.
8. Um novo Virtual Device deve ter sido criado. Clique na seta verde em Actions para iniciá-lo.
9. Na página do projeto do Android Studio, pressione Shift+F10. A máquina virtual deve abrir e iniciar o programa.

Obrigado pela atenção! Se tiver algum problema para rodar, por favor entre em contato com rafael.olivier.cardoso@gmail.com